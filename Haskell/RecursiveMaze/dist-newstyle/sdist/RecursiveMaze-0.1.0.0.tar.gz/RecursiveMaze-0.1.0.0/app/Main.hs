import Data.List (minimumBy)
import Data.Ord (comparing)
import System.IO (hFlush, stdout)
import System.Random (randomRIO)

entropy :: [Double] -> Double
entropy [] = 0
entropy xs =
  let mean = sum xs / fromIntegral (length xs)
  in sum $ map (\x -> abs (x - mean)) xs

selectNext :: Double -> [Double] -> (Double, [Double])
selectNext prev xs = (next, filter (/= next) xs)
  where
    entropies = map (\x -> (x, entropy (x:xs))) xs
    next = fst $ minimumBy (comparing snd) entropies

main :: IO ()
main = do
  putStrLn "Enter a list of numbers separated by spaces:"
  hFlush stdout
  input <- getLine
  let numbers = map read (words input)
  randomIndex <- randomRIO (0, length numbers - 1)
  let (first, remaining) = splitAt randomIndex numbers
  loop first remaining
  where
    loop prev xs = do
      putStr $ "Next number (entropy with " ++ show prev ++ "): "
      hFlush stdout
      let (next, remaining) = selectNext prev xs
      putStrLn $ show next
      case remaining of
        [] -> return ()
        _ -> loop next remaining
